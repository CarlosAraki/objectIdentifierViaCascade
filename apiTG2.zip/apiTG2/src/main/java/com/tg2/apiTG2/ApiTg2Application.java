package com.tg2.apiTG2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiTg2Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiTg2Application.class, args);
	}

}

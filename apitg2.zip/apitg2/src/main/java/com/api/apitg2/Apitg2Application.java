package com.api.apitg2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Apitg2Application {

	public static void main(String[] args) {
		SpringApplication.run(Apitg2Application.class, args);
	}

}
